<script setup>

import Sidebar from './components/Sidebar.vue';
import { RouterView } from 'vue-router'; // Mengimpor RouterView dari vue-router
</script>

<template>
  <Sidebar />
</template>

<style scoped>

</style>
