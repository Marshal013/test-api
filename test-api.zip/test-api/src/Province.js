// province.js
export function getCitiesByProvinceId(provinceId) {
    // Implementasi untuk mendapatkan daftar kota berdasarkan ID provinsi
}

// city.js
export function getProvinceNameByCityId(cityId) {
    // Implementasi untuk mendapatkan nama provinsi berdasarkan ID kota
}

// province.js
export function sortProvinces(provinces, sortBy = 'asc') {
    // Implementasi untuk mengurutkan array provinsi berdasarkan ID & nama provinsi (asc/desc)
}
